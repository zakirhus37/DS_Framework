package practise.AppiumFramework;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import pageObjects.HomePage;
import pageObjects.ServicesPage;

public class loginForum_tc extends base {

	@Test(priority = 1, description = "Login")
	public void Login() throws IOException, InterruptedException {
		service = startServer();
		
		AndroidDriver<AndroidElement> driver = capabilities("DigitalSaathi");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		HomePage hm = new HomePage(driver);
		Utilities u = new Utilities(driver);

		Thread.sleep(600);
		hm.English.click();
		Thread.sleep(600);
		hm.Nextbtn.click();
		hm.Nextbtn.click();
		hm.Nextbtn.click();
		hm.Skipbtn_Onboarding.click();
		Thread.sleep(500);
		hm.Accept.click();
		Thread.sleep(600);

		u.setExplixitWait(hm.phoneNumber);
		hm.phoneNumber.sendKeys("9940306162");
		Thread.sleep(1200);
		hm.continueBtn.click();
		Thread.sleep(1200);
		hm.nationalNumber.sendKeys("9940306162");
		Thread.sleep(1200);
		hm.continueBtn.click();
		Thread.sleep(1200);

	     u.setExplixitWait(hm.verificationCode);
	     System.out.println("Waiting for the otp");
	     Thread.sleep(2000);
	     driver.openNotifications();
	     hm.smsNotification.click();
	     Thread.sleep(3000);
	    
	     
	     String smsreceived1 = hm.otp_SMS.getText();
	     System.out.println(smsreceived1);
	     
//	     String smsreceived = hm.SMSdisplayed.getText();
//	     System.out.println(smsreceived);
//	     
//	     String[] arrOfStr = smsreceived.split(" ", 5);
//	     System.out.println(arrOfStr[3]);
//	     String OTP= arrOfStr[3];
	     
	     driver.pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	     hm.verificationCode.sendKeys(smsreceived1);
	     hm.continueBtn.click();
	     
	     hm.Nextbtn.click();																																																																																																																																																																																						
	     hm.Skipbtn_Afterlogin.click();
	     System.out.println("Logged in Successfully");

		hm.Profile.click();
		String ver = hm.versionNumber.getText();
		System.out.println("DS app Version number :" + ver);

		// service.stop(); - commented intentionally
	}

	
	  @Test(priority=2, enabled = false, description="Forum") 
	  
	  public void Forum() throws
	  IOException, InterruptedException 
	  { 
	  Utilities u=new Utilities(driver);
	  ServicesPage sp = new ServicesPage(driver); 
	  HomePage hm = new HomePage(driver);
	  driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	  
	  
	  hm.Forum.click(); 
	  Thread.sleep(2000); 
	  hm.search.sendKeys("Maize");
	  hm.forumSearchBtn.click(); 
	  Thread.sleep(1000); 
	  hm.search.sendKeys("Paddy");
	  Thread.sleep(1000);
	  hm.forumSearchBtn.click();
	  
	  hm.forumFilterBtn.click(); 
	  hm.TrendingRadio.click();
	  hm.ApplyBtn_Filter.click(); 
	  Thread.sleep(1000); 
	  hm.forumFilterBtn.click(); 
	  hm.FeaturedRadio.click();
	  hm.ApplyBtn_Filter.click(); 
	  Thread.sleep(1000);
	  hm.forumFilterBtn.click();
	  hm.YourPostsRadio.click(); 
	  hm.ApplyBtn_Filter.click(); 
	  Thread.sleep(1000);
	  
	  
	  
	  hm.createPost.click();
	  hm.postContent.sendKeys("Automation Test"); 
	  hm.add_attachments.click();
	  hm.Albums.click(); 
	  hm.PaddyAlbum.click(); 
	  hm.selectPic.click();
	  hm.Postbtn.click();
	  Thread.sleep(2000);
	//  u.scrollDown(); 
	  
	  
	  hm.Likes.click(); 
	  hm.Comments_Zero.click();
	  Thread.sleep(1000);
	  hm.Comment_type.sendKeys("Automation - Test comment");
	  Thread.sleep(2000);
	  hm.Comment_Send.click();
	  Thread.sleep(2000);
	  
	  sp.Backbtn_Enquiry.click(); 
	  Thread.sleep(900); 
	  u.scrollDown();
	  hm.Comments_One.isDisplayed(); 
	  hm.threedots_Forum.click();
	  hm.Report_DD.click(); 
	  hm.It_is_fake.click(); 
	  hm.Report_button.click();
	  
	  sp.threedots_Forum.click(); 
	  sp.delete_Forum.click(); 
	  Thread.sleep(600);
	  
	  // u.scrollIntoView("1 day ago");
	  
	  }
	 

	@Test(priority = 3, enabled = false, description = "MarketPrice")
	public void MarketPrice() throws IOException, InterruptedException {
		HomePage hm = new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);

		hm.market.click();
		Thread.sleep(500);
		hm.addMore.click();
		Thread.sleep(1000);
		hm.add_crop.click();
		Thread.sleep(600);
		hm.searchTextBox.sendKeys("Turmeric");
		Thread.sleep(600);
		hm.searchCloseBtn.click();
		Thread.sleep(600);
	//	hm.cropText.click();
		Thread.sleep(600);
		hm.Backbtn_DSApp.click();
		Thread.sleep(600);
		hm.discardBtn.click();
		Thread.sleep(600);
		hm.done.click();
		
//		Thread.sleep(800);
//		hm.crop_marketPrice.click();
//		Thread.sleep(600);
//		hm.selectVariety.click();
//		hm.cropVariety.click();
//		hm.applyVariety.click();
//		hm.allMarkets.click();

	}

	/*
	 * @BeforeTest public void killAllNodes() throws IOException,
	 * InterruptedException { //taskkill /F /IM node.exe
	 * Runtime.getRuntime().exec("taskkill /F /IM node.exe"); Thread.sleep(3000);
	 * 
	 * }
	 */

//	public static double getAmount(String value) {
//		value = value.substring(1);
//		double amount2value = Double.parseDouble(value);
//		return amount2value;
//	}

}

package practise.AppiumFramework;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import pageObjects.NewsProfile;
import pageObjects.ServicesPage;


public class newsProfile_tc extends base{
     
	@Test(priority=11, description="News")
	public void News() throws IOException, InterruptedException
	{
		 Utilities u=new Utilities(driver);
	     ServicesPage sp = new ServicesPage(driver); 
	     NewsProfile np = new NewsProfile(driver);
	     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
	     
	     np.news.click();
	     u.SwipeScreen(np.newsCarouselimage);
	     u.SwipeScreen(np.newsCarouselimage);
	     np.secondNews.click();
	     
/*	     try
	     {
	     np.imagePreviewNewsBtn.click();
	     u.AndroidBack();
	     }
	     catch (Exception ex) 
	     {
	     u.AndroidBack();
	     System.out.println(ex.getMessage());
	     }*/
	     
	     sp.Backbtn_Enquiry.click();
	     Thread.sleep(800);
	     // u.scrollDownHalf();
	}
	

	
	
	
	@Test(priority=12, description="Profile")
	public void EditProfile() throws IOException, InterruptedException
	{
		 Utilities u=new Utilities(driver);
	     HomePage hm = new HomePage(driver);  
	     NewsProfile np = new NewsProfile(driver);
	     ServicesPage sp = new ServicesPage(driver); 
	     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
	     
	     //Update Profile Image Picture
	     hm.Profile.click(); 
	     Thread.sleep(500);
	     np.editProfile.click();
	     np.updateProfile.click();
	     np.camera.click();
	     u.setExplixitWait(sp.CameraButton);
	     sp.CameraButton.click();
	     Thread.sleep(500);
	     sp.TikButton.click();
	     Thread.sleep(500);
	     
	     
	     //Edit Personal Details
	     
	     np.edit_user_profile_btn.click();
	     Thread.sleep(500);
	     
	     np.userType.click();
	     Thread.sleep(500);
	     np.state.click();
	     Thread.sleep(500);
	     
	     np.district.click();
	     Thread.sleep(500);
	     np.state.click();
	     Thread.sleep(500);
	     

	     np.district.click();
	     Thread.sleep(500);
	     
	     np.subDistrict.click();
	     Thread.sleep(500);
	     
	     np.saveChanges.click();
	     Thread.sleep(800);     
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(500);  
	
	}
	
	
	@Test(priority=13, description="Profile")
	public void Profile() throws IOException, InterruptedException
	{
		 Utilities u=new Utilities(driver);
	     HomePage hm = new HomePage(driver);  
	     NewsProfile np = new NewsProfile(driver);
	     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
	     
	     hm.Profile.click();
	     
	  // u.scrollIntoView("UPDATE");
	     
	     np.Usermanual.click();
	     u.scrollDown();
	     u.AndroidBack();
	     
	     np.helpSupport.click();
	     Thread.sleep(1000);
	     u.AndroidBack();
	     Thread.sleep(1000);
	     
	     np.rateDigitalSaathi.click();
	     Thread.sleep(1000);
	     u.AndroidBack();
	     Thread.sleep(1000);
	     
	     np.KYCDocument.click();
	     Thread.sleep(1000);
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(1000);
	    
	     
	     np.privacyPolicy.click();
	     u.AndroidBack();
	     Thread.sleep(1000);
	     
	     np.notificationSettings.click();
	     Thread.sleep(1000);
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(1000);
	     
//	     np.language.click();
//	     hm.Kannada.click();
//	     hm.logout_kannada.click();
//	     u.AndroidBack();
	    
	}
	
	
	@Test(priority=14, description="Logout")
	public void Logout() throws IOException, InterruptedException
	{
	     NewsProfile np = new NewsProfile(driver); 
	     np.logOut.click();
	     Thread.sleep(600);
	     np.logout_Yes.click();
	     Thread.sleep(600);     
	}
	     

}

package practise.AppiumFramework;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.OtherPages;
import pageObjects.ServicesPage;


public class services_tc extends base{
	
	
	@Test(priority=4, enabled = false, description="WeatherForecast")
	public void WeatherForecast() throws IOException, InterruptedException
	{ 
		 Utilities u=new Utilities(driver);
	     HomePage hm = new HomePage(driver);  
	     OtherPages op = new OtherPages(driver);
	     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	     
	     hm.service.click();
	     
	     String temp1= op.servicesWeatherTemp.getText();
	     System.out.println("Weather temperature displayed: " +temp1);
	     
	     op.viewDailyForecast.click();
	     Thread.sleep(1200);
	     op.weatherTop.isDisplayed();
	     Thread.sleep(1200);
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(500);
	     
	     //Digital Saathi says
	     op.todaysSuggestionShareBtn.click();
	     op.Share.isDisplayed();
	     u.AndroidBack();
	     Thread.sleep(900);
	}
	
	
	@Test(priority=5, enabled = false,description="Agri Input MarketPlace")
	public void AgriInputMarketPlace() throws IOException, InterruptedException
	{ 
	     ServicesPage sp = new ServicesPage(driver);
	     HomePage hm = new HomePage(driver);  
	     Utilities u=new Utilities(driver);
	     
	     hm.service.click();
	     Thread.sleep(500);
	     sp.agriInputMarketPlace.click();
	     sp.agree_Disclaimer.isDisplayed();
	     u.AndroidBack();
	     
	}
		
	
	@Test(priority=6, enabled=false, description="Crop Sell Offer")
	public void CropSellOffer() throws IOException, InterruptedException
	{ 
	     ServicesPage sp = new ServicesPage(driver);
	     HomePage hm = new HomePage(driver);  
	     Utilities u=new Utilities(driver);
	     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	     
	     hm.service.click();
	     Thread.sleep(500);
	     
	     sp.cropSellOFfer.click();
	     Thread.sleep(600);  
	     sp.start_CSO.click();
	     Thread.sleep(600);
	     sp.create_CSO.click();
	     Thread.sleep(600);
	     sp.agree_CSO.click();
	     Thread.sleep(600);
	     
	     sp.cropName.click();
	     Thread.sleep(500); 
	     sp.state_CSO.click();
	     Thread.sleep(900);  
	     
	     sp.district_CSO.click();
	     Thread.sleep(1200);
	     sp.subDistrict_CSO.click();
	     Thread.sleep(2200);  
	     
	     sp.village_CSO.click();
	     Thread.sleep(2000);
	     sp.subDistrict_CSO.click();
	     Thread.sleep(1200);
	     
	     sp.quantity_CSO.sendKeys("23.45");
	     Thread.sleep(900);
	     
	     sp.unit_CSO.click();
	     Thread.sleep(2000);
//	     sp.selectBAG_CSO.click();
//	     Thread.sleep(500);
	     
	     sp.uploadImage.click();
	     Thread.sleep(800);
	     sp.camera_CSO.click();
	     Thread.sleep(300);
	     sp.CameraButton.click();
	     u.setExplixitWait(sp.TikButton);
	     sp.TikButton.click();
	     
	     sp.submit_CSO.click();
	     Thread.sleep(900);
	     sp.ok_CSO.click();
	     Thread.sleep(900);
	     
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(400);
	     hm.Backbtn_DSApp.click();
	     Thread.sleep(400);
		
	}
	
	
		@Test(priority=7,  description="Crop Doctor")
		public void CropDoctor()  throws IOException, InterruptedException
		{ 
		     ServicesPage sp = new ServicesPage(driver);
		     HomePage hm = new HomePage(driver);  
		     Utilities u=new Utilities(driver);
		     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		         
		     hm.service.click();
		     sp.cropDoctor.click();
		     sp.Maize_CD.click();
		     System.out.println("Crop doctor");
		     Thread.sleep(500);
		     sp.takePhoto.click();
		     u.setExplixitWait(sp.CameraButton);
		     sp.CameraButton.click();
		     Thread.sleep(500);
		     sp.TikButton.click();
		     Thread.sleep(500);
		     sp.AskInForum.click();
		     sp.PostTitle.sendKeys("Automation Test");
		     sp.CD_POST.click();
		    
		     Thread.sleep(2000);
		     u.scrollDown();
		     Thread.sleep(600);
//		     hm.threedots_Forum.click();
//		     Thread.sleep(800);
//		     hm.delete_Forum.click();
		 	 System.out.println("\nCrop Doctor for Maize Crop validated -- PASS ");
		 	 
		 	
//		 	 hm.service.click();
//		 	 sp.cropDoctor.click();
//		     sp.CD_Paddy.click();
//		     sp.takePhoto.click();
//		     sp.CameraButton.click();
//		     u.setExplixitWait(sp.TikButton);
//		     sp.TikButton.click();
//		     sp.AskInForum.click();
//		     sp.PostTitle.sendKeys("Automation Test");
//		     sp.CD_POST.click();
//		     
//		     Thread.sleep(600);
//		     u.scrollDown(); 
//		     hm.threedots_Forum.click();
//		     hm.delete_Forum.click();
//		     System.out.println("Crop Doctor for Paddy Crop validated -- PASS ");
//		 	 Thread.sleep(1000);
		}


		@Test(priority=8, description="Crop Practice")
		public void CropPractice() throws IOException, InterruptedException
		{ 
		     ServicesPage sp = new ServicesPage(driver);
		     HomePage hm = new HomePage(driver);  
		     
		     hm.service.click();
		     sp.CropPractice.click();
		     sp.CP_Maize.click();
		     sp.SelectDate_btn.click();
		     sp.clickonDate.click();
		     sp.OK_SowDate.click();
		     String plannedSowingDate = sp.PlannedSowingDate.getText();
		     System.out.println("\nCrop Practice - Planned Sowing Date :" +plannedSowingDate);
		     sp.CP_NextBtn.click();
		     sp.CP_NextBtn.click();
		     sp.CP_NextBtn.click();
		     sp.CP_NextBtn.click();
		     
		     Thread.sleep(600);
		     sp.CP_Paddy.click();
		     sp.CP_NextBtn.click();
		//   sp.CP_NextBtn.click();
		//   Thread.sleep(600);
		     sp.Backbtn_Enquiry.click();
		 	 System.out.println("Crop Practice verified successfully -- PASS"); 
		}
			
			
		
		@Test(priority=9, description="Contact Us")
		public void ContactUs() throws IOException, InterruptedException
		{ 
		     ServicesPage sp = new ServicesPage(driver);
		     HomePage hm = new HomePage(driver);  

		     hm.service.click();
		     sp.contactUs.click();
		     sp.Backbtn_Enquiry.click();
		}
		
		@Test(priority=10, description="FeedBack")
		public void FeedBack() throws IOException, InterruptedException
		{ 
		     ServicesPage sp = new ServicesPage(driver);
		     HomePage hm = new HomePage(driver);  

		     hm.service.click();
		     sp.feedback.click();
		     sp.greatSimley.click();
		     sp.feedbackComment.sendKeys("App looks great");
		     sp.FeedbackSubmitBtn.click();
		}
		     
	
}

package resources;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.xml.XmlSuite;

 
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

 
public class ExtentReporterNG implements IReporter {
    
	public ExtentReports extent; //it was private before
    ExtentHtmlReporter htmlReporter;
    public ExtentTest logger;
 
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
    	
        htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\Reports\\DigitalSaathi_Report.html");
       // htmlReporter.loadXMLConfig(System.getProperty("user.dir")+ "\\extent-config.xml");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        
		htmlReporter.config().setDocumentTitle("Digital Saathi"); 
		htmlReporter.config().setReportName("Digital Saathi - Automation Test Results"); 
		htmlReporter.config().setTheme(Theme.DARK);		
		
        extent.setSystemInfo("Organization", "Cargill - Digital Saathi project");
        extent.setSystemInfo("Environment", "Stage build");
		extent.setSystemInfo("Automation Tester", "Zakir Hussain");
		extent.setSystemInfo("Build number", "2.7_RC1");
		
        
     for (ISuite suite : suites) {
            Map<String, ISuiteResult> result = suite.getResults();
 
            for (ISuiteResult r : result.values()) {
                ITestContext context = r.getTestContext();
 
                buildTestNodes(context.getPassedTests(), Status.PASS);
                buildTestNodes(context.getFailedTests(), Status.FAIL); 
                buildTestNodes(context.getSkippedTests(), Status.SKIP);
                
            }
        }
     
      //To print the TestRunner Logs
    	for (String s : Reporter.getOutput()) 
    	{
    		extent.setTestRunnerOutput(s);

    	}

        extent.flush();
    }
    
    
 //Commenting it intentionally
    private void buildTestNodes(IResultMap tests, Status status) {
        ExtentTest test;
 
        if (tests.size() > 0) {
            for (ITestResult result : tests.getAllResults()) {
                test = extent.createTest(result.getMethod().getMethodName());
 
          
                test.getModel().setStartTime(getTime(result.getStartMillis()));
    			test.getModel().setEndTime(getTime(result.getEndMillis()));
 
                for (String group : result.getMethod().getGroups())
                    test.assignCategory(group);
 
                String message = "Test " + status.toString().toLowerCase() + "ed";
                if (result.getThrowable() != null) 
                {
                    message = result.getThrowable().getMessage();
                    
                    test.log(status, MarkupHelper.createLabel(result.getName(),ExtentColor.RED));
                    test.log(status, message); 
                    // extent.endTest(test);
                }
                else
                {
                test.log(status, MarkupHelper.createLabel(result.getName(),ExtentColor.GREEN));
                test.log(status, message);
                test.info("All steps executed successfully");
                }
 
          //      extent.endTest(test);
                test.getModel().setStartTime(getTime(result.getStartMillis()));
    			test.getModel().setEndTime(getTime(result.getEndMillis()));
            }
        }
    }
 
    private Date getTime(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar.getTime();        
    }
    
    // ----------------------------------------------------------------------------------------------------//
/*    public void onTestSuccess(ITestResult tr)
    {
     logger=extent.createTest(tr.getName()); // create new entry in th report
     logger.log(Status.PASS,MarkupHelper.createLabel(tr.getName(),ExtentColor.GREEN)); // send the passed information to the report with GREEN color highlighted
    }
    
    public void onTestFailure(ITestResult tr)
    {
     logger=extent.createTest(tr.getName()); // create new entry in th report
     logger.log(Status.FAIL,MarkupHelper.createLabel(tr.getName(),ExtentColor.RED)); // send the passed information to the report with GREEN color highlighted
     
     String screenshotPath=System.getProperty("user.dir")+"\\Screenshots\\"+tr.getName()+".png";
     try {
      logger.fail("Screenshot is below:" + logger.addScreenCaptureFromPath(screenshotPath));
     } catch (IOException e) {
       e.printStackTrace();
     } 
    }
    
    public void onTestSkipped(ITestResult tr)
    {
     logger=extent.createTest(tr.getName()); // create new entry in th report
     logger.log(Status.SKIP,MarkupHelper.createLabel(tr.getName(),ExtentColor.ORANGE));
    }
    public void onFinish(ITestContext testContext)
    {
     extent.flush();
    }*/
    
}

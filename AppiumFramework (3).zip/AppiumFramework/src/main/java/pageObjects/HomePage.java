package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage {
// Is to call the driver object from testcase to Pageobject file
	
	//Concatenate driver
	public HomePage(AndroidDriver<AndroidElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/*
	 Sample for list<Webelements> ---------------------
	 @AndroidFindBy(className="android.widget.Button") 
	 public List<WebElement> buttons;
	 */
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='ENGLISH']")
	public WebElement English;
	
	@AndroidFindBy(id="android:id/button2")
	public WebElement Kannada;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='ಭಾಷೆ']")
	public WebElement logout_kannada;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/nextBtn")
	public WebElement Nextbtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/prevBtn")
	public WebElement Skipbtn_Onboarding;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/accept")
	public WebElement Accept;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@resource-id='phoneNumber']")
	public WebElement phoneNumber;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='Continue']")
	public WebElement continueBtn;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@resource-id='nationalNumber']")
	public WebElement nationalNumber;
	
	@AndroidFindBy(xpath="//android.widget.EditText[@resource-id='verificationCode']")
	public WebElement verificationCode;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='Copy OTP']")
	public WebElement CopyOTP;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='Call Me']")
	public WebElement callMe;
	
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'… code')]")
	public WebElement smsNotification;
	
	
	@AndroidFindBy(id="com.android.mms.id/action_btn")
	public WebElement Copy_SMS;
	
	@AndroidFindBy(id="com.android.mms:id/action_value")
	public WebElement otp_SMS;
	
	
	
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Use verification code')]")
	public WebElement SMSdisplayed;
	
	@AndroidFindBy(xpath="//android.view.View[@text='Please verify your country code and phone number']")
	public WebElement Paste;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/skipBtn")
	public WebElement Skipbtn_Afterlogin;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/navigation_user_profile")
	public WebElement Profile;
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/UserProfileVersionNumber")
	public WebElement versionNumber;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/inputSearch")
	public WebElement search;
	
	
	// Forum
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/forumSearchBtn")
	public WebElement forumSearchBtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/forumFilterBtn")
	public WebElement forumFilterBtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/SortByTrendingRadio")
	public WebElement TrendingRadio;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='APPLY']")
	public WebElement ApplyBtn_Filter;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/SortByFeaturedRadio")
	public WebElement FeaturedRadio;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/SortByYourPostsRadio")
	public WebElement YourPostsRadio;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/navigation_services")
	public WebElement service;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/CreatePostBtn")
	public WebElement createPost;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/postContent")
	public WebElement postContent;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/create_post")
	public WebElement Postbtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/add_attachments")
	public WebElement add_attachments;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Albums']")
	public WebElement Albums;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='paddy']")
	public WebElement PaddyAlbum;
	
	@AndroidFindBy(id="com.miui.gallery:id/pick_num_indicator")
	public WebElement selectPic;
	
	@AndroidFindBy(xpath="//com.miui.gallery[@class='android.widget.ImageView']")
	public WebElement selectPicture;
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/navigation_community")
	public WebElement Forum;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/PostLikeBtn")
	public WebElement Likes;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='0 Comments']")
	public WebElement Comments_Zero;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/comment")
	public WebElement Comment_type;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/DetailedPostComment")
	public WebElement Comment_Send;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='1 Comments']")
	public WebElement Comments_One;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/DetailedPostOverFlowMenu")
	public WebElement threedots_Forum;
		
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Report']")
	public WebElement Report_DD;
	
	@AndroidFindBy(xpath="//android.widget.RadioButton[@text='It is fake']")
	public WebElement It_is_fake;

	@AndroidFindBy(xpath="//android.widget.Button[@text='REPORT']")
	public WebElement Report_button;	
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Delete']")
	public WebElement delete_Forum;
	
	
	//Market Place
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/navigation_market_price")
	public WebElement market;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/addmore_img")
	public WebElement addMore;
	
	@AndroidFindBy(xpath="//android.widget.ImageView[@bounds='[110,930][253,1073]']")
	public WebElement add_crop;

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/search_src_text")
	public WebElement searchTextBox;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/search_close_btn")
	public WebElement searchCloseBtn;
	
	@AndroidFindBy(xpath="//android.widget.ImageButton[@index='0']")
	public WebElement Backbtn_DSApp;
	
	@AndroidFindBy(id="android:id/button2")
	public WebElement discardBtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/done")
	public WebElement done;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/crop_img_view")
	public WebElement crop_marketPrice;
	

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/commodity_variety_list")
	public WebElement selectVariety;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/item_crop_variety")
	public WebElement cropVariety;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/apply_variety")
	public WebElement applyVariety;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/distance_all")
	public WebElement allMarkets;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/loc_market_container")
	public WebElement locationMarket;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/distanceSortBtn")
	public WebElement distanceSortBtn;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/priceSortBtn")
	public WebElement priceSortBtn;
	
	
	
}
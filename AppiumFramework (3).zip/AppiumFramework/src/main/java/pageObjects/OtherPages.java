package pageObjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;


public class OtherPages {

	public OtherPages(AndroidDriver<AndroidElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	//Examples ----------------------------------------------------------------------------------
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/productPrice")
	public List<WebElement> productList;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/totalAmountLbl")
	public WebElement totalAmount;
	
	public List<WebElement> getProductList()
	{
		
		return productList;
	}
	
	//Weather
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesWeatherTemp")
	public WebElement servicesWeatherTemp;
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/viewDailyForecast")
	public WebElement viewDailyForecast;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/weatherTop")
	public WebElement weatherTop;
	
	@AndroidFindBy(xpath="//android.widget.FrameLayout[@bounds='[55,309][1025,2006]']")
	public WebElement weatherPanel;
	
	
	
	//Digital Saathi Says

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/todaysSuggestionShareBtn")
	public WebElement todaysSuggestionShareBtn;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Share']")
	public WebElement Share;
}


package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;


public class ServicesPage {

	public ServicesPage(AndroidDriver<AndroidElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	   
	//AgriInput MarketPlace -------------------------------------------------------------------

	@AndroidFindBy(xpath="//android.widget.ImageButton[@index='0']")
	public WebElement Backbtn_Enquiry;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesCropInput")
	public WebElement agriInputMarketPlace;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/market_enquiry_disclaimer_accept")
	public WebElement agree_Disclaimer;
	
	
	
	//Crop Sell Offer -----------------------------------------------------------
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesCropSell")
	public WebElement cropSellOFfer;
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/guide")
	public WebElement guide_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/start")
	public WebElement start_CSO;	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/market_enquiry_create_enquiry_btn")
	public WebElement create_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/market_enquiry_disclaimer_accept")
	public WebElement agree_CSO;
	
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/productTypeSpinner")
	public WebElement cropName;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/state_editbox")
	public WebElement state_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/district_editbox")
	public WebElement district_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/subDistrict_editbox")
	public WebElement subDistrict_CSO;
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/village_editbox")
	public WebElement village_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/EditTextQuantity")
	public WebElement quantity_CSO;
	
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/quantitySpinner")
	public WebElement unit_CSO;

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/textNeedToUpload")
	public WebElement selectBAG_CSO;

	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Upload an image')]")
	public WebElement uploadImage;

	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Camera')]")
	public WebElement camera_CSO;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/SubmitEnquiryRequest")
	public WebElement submit_CSO;

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/homeBtn")
	public WebElement ok_CSO;
	

	//Crop Doctor -----------------------------------------------------------
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/pest_control")
	public WebElement cropDoctor;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/pest_control_maize_label")
	public WebElement Maize_CD;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/pest_control_paddy_label")
	public WebElement CD_Paddy;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Take Photo']")
	public WebElement takePhoto;
	
	@AndroidFindBy(id="com.android.camera:id/shutter_button_horizontal")
	public WebElement CameraButton;
	
	@AndroidFindBy(id="com.android.camera:id/done_button")
	public WebElement TikButton;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/post_forum_btn")
	public WebElement AskInForum;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/CreatePostTitle")
	public WebElement PostTitle;
	
	@AndroidFindBy(xpath="//android.widget.Button[@text='POST']")
	public WebElement CD_POST;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/DetailedPostOverFlowMenu")
	public WebElement threedots_Forum;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='Delete']")
	public WebElement delete_Forum;
	
	
	//Crop Practice ------------------------------------------------------------

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/crop_practice")
	public WebElement CropPractice;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/crop_practice_maize_label")
	public WebElement CP_Maize;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/crop_practice_paddy_label")
	public WebElement CP_Paddy;

	@AndroidFindBy(id="cargill.com.digitalsaathi:id/sowing_date")
	public WebElement SelectDate_btn;
	
	@AndroidFindBy(xpath="//android.widget.TextView[@text='19']")
	public WebElement clickonDate;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/confirm_button")
	public WebElement OK_SowDate;
		
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/pest_control_sowing_date_textview")
	public WebElement PlannedSowingDate;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/stepNumberPopForwardArrow")
	public WebElement CP_NextBtn;
	
	
	
	
	//Contact us -----------------------------------------------------------
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesContact")
	public WebElement contactUs;
	
	//Feedback -----------------------------------------------------------
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesFeedback")
	public WebElement feedback;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/feedback_great_label")
	public WebElement greatSimley;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/FeedbackCommentTextInputEditText")
	public WebElement feedbackComment;
	
	@AndroidFindBy(id="cargill.com.digitalsaathi:id/servicesFeedbackSubmitBtn")
	public WebElement FeedbackSubmitBtn;
	
}

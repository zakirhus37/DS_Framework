package pageObjects;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class NewsProfile {

	public NewsProfile(AndroidDriver<AndroidElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
		//Examples
		@AndroidFindBy(className="android.widget.Button")
		public List<WebElement> buttons;

		//News --------------------------------------------------------------------------
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/navigation_news")
		public WebElement news;
		
		@AndroidFindBy(id="android.widget.TextView[@text='2 day ago']")
		public WebElement daysAgo;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/article_desc")
		public WebElement secondNews;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/imagePreviewNewsBtn")
		public WebElement imagePreviewNewsBtn;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/sliderViewPager")
		public WebElement newsCarouselimage;
		
		
		//Edit Profile -------------------------------------------------------------
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/UserProfileEdit")
		public WebElement editProfile;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/UpdateProfile_update_imageView")
		public WebElement updateProfile;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Camera']")
		public WebElement camera;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/Edit_user_profile_btn")
		public WebElement edit_user_profile_btn;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/userType_editbox")
		public WebElement userType;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/state_editbox")
		public WebElement state;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/district_editbox")
		public WebElement district;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/subDistrict_editbox")
		public WebElement subDistrict;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/village_editbox")
		public WebElement village;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/Update_user_profile_btn")
		public WebElement saveChanges;
		
		
		//Profile
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/UserProfileUserName")
		public WebElement userName_Profile;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/UpdateProfile_edittext_village")
		public WebElement villageName;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/UpdateProfile_edittext_farm_area")
		public WebElement farmArea;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/btnSaveButton")
		public WebElement updateBtn;
			
		@AndroidFindBy(xpath="//android.widget.TextView[@text='User manual']")
		public WebElement Usermanual;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Help and Support']")
		public WebElement helpSupport;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='KYC Document']")
		public WebElement KYCDocument;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Share App']")
		public WebElement shareApp;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Rate Digital Saathi']")
		public WebElement rateDigitalSaathi;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Language']")
		public WebElement language;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Privacy Policy']")
		public WebElement privacyPolicy;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Notification Settings']")
		public WebElement notificationSettings;
		
		@AndroidFindBy(id="cargill.com.digitalsaathi:id/switchSettings']")
		public WebElement togglenotificationSettings;
		
		@AndroidFindBy(xpath="//android.widget.TextView[@text='Log Out']")
		public WebElement logOut;

		@AndroidFindBy(id="android:id/button1")
		public WebElement logout_Yes;

}

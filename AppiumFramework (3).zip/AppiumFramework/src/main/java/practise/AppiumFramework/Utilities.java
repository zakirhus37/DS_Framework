package practise.AppiumFramework;

import org.openqa.selenium.WebElement;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import java.time.Duration;
import java.util.Random;

import org.openqa.selenium.Dimension;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class Utilities {
	AndroidDriver<AndroidElement>  driver;

	public Utilities(AndroidDriver<AndroidElement> driver)
	{
		this.driver=driver;
	}

	
	public void scrollToText(String text)
	{
	     driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\""+text+"\"));");
	}
	public void setExplixitWait(final WebElement Locator){
		   try{
			   WebDriverWait wait = new WebDriverWait(driver, 120);
			   wait.until(ExpectedConditions.visibilityOf(Locator));
		   		}
		 catch(Exception ex){
			 System.out.println(ex.getStackTrace());
		 		}
	   		}
	
	public void press1(final WebElement Locator) {

 AndroidTouchAction touch = new AndroidTouchAction(driver);
	touch.longPress(LongPressOptions.longPressOptions()
	                .withElement (ElementOption.element (Locator)))
	                .perform ();
	System.out.println("LongPressed Tapped");
	}
	
	public void ScrollToVisibleText(String visibleText) {
		     driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+visibleText+"\").instance(0))").click();
		        }
		    
	public void scrollIntoView(String Text){
     driver.findElementByAndroidUIAutomator(
             "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + Text + "\").instance(0))");
 }
	
	public void scrollDown()
	{
     Dimension dimension = driver.manage().window().getSize();
     int scrollStart = (int) (dimension.getHeight() * 0.5);
     int scrollEnd = (int) (dimension.getHeight() * 0.8);

     TouchAction touchAction = new TouchAction(driver);
     touchAction.press(PointOption.point(0, scrollStart))
             .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
             .moveTo(PointOption.point(0, scrollEnd))
             .release().perform();
     }


	
	public void hortizonalSwipe()
	{
		Dimension dim = driver.manage().window().getSize();
		int height = dim.getHeight();
		int width = dim.getWidth();
		int x = width/2;
		int starty = (int)(height*0.80);
		int endy = (int)(height*0.20);
		
		TouchAction touchAction = new TouchAction(driver);
	    touchAction.longPress(PointOption.point(x, starty))
	               .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(10)))
	               .moveTo(PointOption.point(endy, 500))
	               .release()
	               .perform();
	    
	    //https://www.tabnine.com/code/java/methods/io.appium.java_client.TouchAction/longPress
}


	public void AndroidBack() {
		driver.pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	}
	
	public String RandomString() {
		    String upperAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		    String lowerAlphabet = "abcdefghijklmnopqrstuvwxyz";
		    String numbers = "0123456789";
		    String alphaNumeric = upperAlphabet + lowerAlphabet + numbers;
		    StringBuilder sb = new StringBuilder();

		    Random random = new Random();
		    int length = 10;

		    for(int i = 0; i < length; i++) {
		    	// generate random index number
		      int index = random.nextInt(alphaNumeric.length());
		      char randomChar = alphaNumeric.charAt(index);
		      sb.append(randomChar);
		    }
		    String randomString = sb.toString();
		    return randomString;
		  }
	
	public  void SwipeScreen(WebElement el) throws InterruptedException {
		WebElement Panel = el;
		Dimension dimension = Panel.getSize();
		
		int Anchor = Panel.getSize().getHeight()/2; 
		
		Double ScreenWidthStart = dimension.getWidth() * 0.8;
		int scrollStart = ScreenWidthStart.intValue();
		
		Double ScreenWidthEnd = dimension.getWidth() * 0.2;
		int scrollEnd = ScreenWidthEnd.intValue();
		
		new TouchAction((PerformsTouchActions) driver)
		.press(PointOption.point(scrollStart, Anchor))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
		.moveTo(PointOption.point(scrollEnd, Anchor))
		.release().perform();
		
		Thread.sleep(200);
		
		//https://qavalidation.com/2016/07/swipe-on-android-device-using-appium.html/
	}
	
	public static double getAmount(String value)
	{
		value= value.substring(1);
		double amount2value=Double.parseDouble(value);
		return amount2value;
	}
		
	}
